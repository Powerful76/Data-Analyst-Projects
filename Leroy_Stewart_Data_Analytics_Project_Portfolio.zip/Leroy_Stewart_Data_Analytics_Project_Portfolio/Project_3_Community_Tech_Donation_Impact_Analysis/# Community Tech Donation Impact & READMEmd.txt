# Community Tech Donation Impact & Engagement Analysis

## Overview
A data‑driven analysis of engagement, donation patterns, and demographics for a community tech‑donation initiative.

## Tools
Survey Design • Excel • Looker • Quantitative Analysis

## Responsibilities
- Designed survey logic, sampling, and validation checks.
- Cleaned and analysed response data.
- Built dashboards showing engagement and donation trends.
- Produced insight summaries and recommendations.

## Impact
- Improved understanding of community engagement behaviour.
- Optimised communication strategies for future donation drives.
- Supported digital inclusion and social impact goals.

## Structure
Survey_Design • Data • Analysis • Looker_Dashboards • Documentation • Outputs
