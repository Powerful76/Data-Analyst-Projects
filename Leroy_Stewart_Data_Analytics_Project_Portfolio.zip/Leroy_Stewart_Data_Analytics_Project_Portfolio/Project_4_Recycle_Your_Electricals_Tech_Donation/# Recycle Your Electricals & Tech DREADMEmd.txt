# Recycle Your Electricals & Tech Donation Initiative

## Overview
A sustainability‑focused project analysing participation, donation volumes, and engagement for a community electricals recycling event.

## Tools
Excel • Community Engagement • Data Analysis • Sustainability Reporting

## Responsibilities
- Coordinated event logistics, drop‑off points, and communications.
- Collected and analysed donation and engagement data.
- Created simple dashboards and participation summaries.
- Produced sustainability impact reports and recommendations.

## Impact
- Increased awareness of responsible recycling.
- Provided insights to improve future community events.
- Supported environmental and digital inclusion goals.

## Structure
Planning • Data • Analysis • Photos • Documentation • Outputs
