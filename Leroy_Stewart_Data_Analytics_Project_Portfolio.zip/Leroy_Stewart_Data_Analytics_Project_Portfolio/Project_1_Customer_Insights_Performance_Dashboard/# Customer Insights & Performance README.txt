# Customer Insights & Performance Reporting Dashboard

## Overview
An end‑to‑end reporting solution built using SQL, Power BI, and Excel to analyse customer behaviour, service performance, and operational KPIs.

## Tools
SQL • Power BI • Power Query • DAX • Excel

## Responsibilities
- Extracted and cleaned customer/service data using SQL.
- Built data models and transformations in Power BI.
- Designed interactive dashboards for KPIs and customer trends.
- Validated data quality and aligned metrics with stakeholders.
- Presented insights using clear data storytelling.

## Impact
- Reduced manual reporting time by 40%.
- Improved visibility of customer and operational performance.
- Enabled faster, data‑driven decision‑making.

## Structure
Data_Model • SQL_Scripts • PowerBI_Files • Documentation • Screenshots
